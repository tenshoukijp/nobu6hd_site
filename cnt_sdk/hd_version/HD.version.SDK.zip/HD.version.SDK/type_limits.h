#pragma once

#define LIMIT_BYTE_MIN	0
#define LIMIT_BYTE_MAX	0xFF

#define LIMIT_CHAR_MIN	-128
#define LIMIT_CHAR_MAX	127

#define LIMIT_WORD_MIN	0
#define LIMIT_WORD_MAX	0xFFFF
