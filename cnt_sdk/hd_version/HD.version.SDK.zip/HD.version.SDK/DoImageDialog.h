#pragma once

void FuncConfirmImageDialogStart(int iImageID);
void FuncConfirmImageDialogEnd();