#pragma once

void On_SelectingScenario(char *szScnearioFileName);
