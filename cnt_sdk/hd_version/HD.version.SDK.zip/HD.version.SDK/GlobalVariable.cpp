#include "GlobalVariable.h"

namespace GlobalVariable {
	int pCurrentProcessBaseAddress = 0;
}