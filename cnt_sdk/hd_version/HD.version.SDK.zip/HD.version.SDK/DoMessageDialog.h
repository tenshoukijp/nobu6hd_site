#pragma once


void FuncConfirmDialogCenter(char *szMessage);
void FuncConfirmDialogBottom(char *szMessage);

void FuncWarningDialogCenter(char *szMessage);

void FuncInfoDialogCenter(char *szMessage);
void FuncInfoDialogBottom(char *szMessage);

int FuncOkCancelDialog(char *szMessage);