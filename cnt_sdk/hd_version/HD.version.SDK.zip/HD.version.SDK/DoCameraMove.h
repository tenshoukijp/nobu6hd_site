#pragma once

void FuncMoveCamera(int iCastleID);
