#pragma once

void FuncFadeIn();
void FuncFadeOut();