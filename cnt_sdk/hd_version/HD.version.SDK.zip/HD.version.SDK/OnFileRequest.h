#pragma once

#include "GameDataStruct.h"

extern char szLastestRequestScenarioOriginalFileName[MAX_PATH];
extern char szLastestRequestScenarioFileName[MAX_PATH];

namespace Native {
	string On_�t�@�C���v����(string strFileName, int iBufAdress);
}