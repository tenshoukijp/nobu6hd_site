#pragma once

namespace GlobalVariable {
	extern int pCurrentProcessBaseAddress;
}