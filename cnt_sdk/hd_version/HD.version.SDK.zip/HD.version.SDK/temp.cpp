/*
FormatMessage
*/

/*
http://schima.hatenablog.com/entry/2014/09/04/214101
*//*
FormatMessage;
ReadProcessMemory;
WriteProcessMemory;
*/

