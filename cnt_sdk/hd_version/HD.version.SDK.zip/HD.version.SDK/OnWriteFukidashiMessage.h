#pragma once

void OnTenshouExeWriteFukidashiMessage(char *szFukidashiFuncLabel);

