﻿using System.Resources;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("天翔記 HD version ユーザーMOD for .NET 4.6")]
[assembly: AssemblyDescription("天翔記 HD version ユーザーMOD for .NET 4.6")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("User.version")]
[assembly: AssemblyCopyright("Powered By 天翔記.jp")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

// このプロジェクトが COM に公開される場合、次の GUID が typelib の ID になります
[assembly: Guid("9fa14cea-07a7-42da-bb3c-ee70f7f2ff42")]

[assembly: AssemblyVersion("0.9.5.0")]
[assembly: AssemblyFileVersion("0.9.5.0")]
[assembly: NeutralResourcesLanguage("ja-JP")]

