// dec_mpg123.cpp : DLL �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include <mmreg.h>
#include "dec_mpg123.h"

//in_mpg123���
#include "mpglib/mpg123.h"
#include "mpglib/mpglib.h"
#include "VbrTag.h"

#define BUF_SIZE 65536

unsigned char WavData[0x14] = {
	0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00, 0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74, 0x20,
	0x12, 0x00, 0x00, 0x00};
unsigned char WavData2[0x8] = {
	0x64, 0x61, 0x74, 0x61, 0x00, 0x00, 0x00, 0x00,
};

HINSTANCE hInst;
bool head_chk(unsigned int head);

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call,LPVOID lpReserved)
{
   switch (ul_reason_for_call)
   {
       case DLL_PROCESS_ATTACH:
       case DLL_THREAD_ATTACH:
           hInst = (HINSTANCE)hModule;
           break;
       case DLL_THREAD_DETACH:
       case DLL_PROCESS_DETACH:
           break;
   }
    return TRUE;
}


DllExport int WINAPI mpg123_dec(char *sInFile, char *sOutFile,FARPROC callback)
{
	FILE *h_infile,*h_outfile;
	
	long file_size = 0;
	int size;
	BYTE out[8192],buf[BUF_SIZE];
	int len,ret;
	DWORD TagSize = 0,itotal_pcm_size = 0;
	WAVEFORMATEX wfx;

	if((h_infile = fopen(sInFile,"rb")) == NULL) return -1;
	if(fseek(h_infile,0,SEEK_END) == 0)	file_size = ftell(h_infile);
	if(file_size == 0)
	{
		fclose(h_infile);
		return -1;
	}

	fseek(h_infile,0,SEEK_SET);
	if((h_outfile = fopen(sOutFile,"wb")) == NULL)
	{
		fclose(h_infile);
		return -2;
	}

	if(callback){
		if(!((dec_callback)callback)(0,file_size)){
			fclose(h_infile);
			return -5;
		}
	}

	//mpg123������
	mpg123 mp3towav;

	len = fread(buf,sizeof(BYTE),BUF_SIZE,h_infile);
	if(len <= 0)
	{
		fclose(h_infile);
		fclose(h_outfile);
		return -3;
	}

	//ID3v2�X�L�b�v
	if(memcmp(buf,"ID3",3) == 0)
	{
		TagSize =	(buf[6] << 21) +
					(buf[7] << 14) +
					(buf[8] << 7) +
					(buf[9] + 10);

		if(fseek(h_infile,TagSize,SEEK_SET) == 0) len = fread(buf,sizeof(BYTE),BUF_SIZE,h_infile);
	}

	//VBR�w�b�_�X�L�b�v
	if(memcmp((BYTE *)buf + 0x24,"Info",4) == 0 || memcmp((BYTE *)buf + 0x24,"Xing",4) == 0)
	{
		VBRTAGDATA vbr_info;

		//VBR�w�b�_�擾
		GetVbrTag(&vbr_info,buf);

		if(fseek(h_infile,TagSize + vbr_info.headersize,SEEK_SET) == 0) len = fread(buf,sizeof(BYTE),BUF_SIZE,h_infile);
	}

	//MPEG Audio�w�b�_���`�F�b�N
	if(!head_chk(((buf[0] << 24) + (buf[1] << 16) + (buf[2] << 8) + buf[3]))){
		//�w�b�_�ɖ�肠��A�o�b�t�@���Ȃ��Ȃ�܂Ő���w�b�_���������Ă݂�B
		int i;
		ret = MP3_ERR;
		for(i=1;i+4 < len;i++){
			if(head_chk(((buf[i] << 24) + (buf[i+1] << 16) + (buf[i+2] << 8) + buf[i+3]))){
				//�f�R�[�h
				ret = mp3towav.decode((const BYTE *)&buf[i],len - i,(BYTE *)out,8192,&size);
				break;
			}
		}
	}else{
		//�f�R�[�h
		ret = mp3towav.decode((const BYTE *)buf,len,(BYTE *)out,8192,&size);
	}

	if(ret == MP3_ERR){
		//�n���h������
		fclose(h_infile);
		fclose(h_outfile);

		return -4;
	}

	//wav�w�b�_��������
	fwrite(WavData,sizeof(BYTE),0x14,h_outfile);

	//wav�w�b�_�쐬
	wfx.wFormatTag = WAVE_FORMAT_PCM;
	wfx.nChannels = mp3towav.get_channel();
	wfx.nSamplesPerSec = mp3towav.get_frequency();
	wfx.wBitsPerSample = 16;
	wfx.nBlockAlign = wfx.nChannels * wfx.wBitsPerSample / 8;
	wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
	wfx.cbSize = 0;

	//wav�w�b�_��������
	fwrite(&wfx,sizeof(BYTE),sizeof(wfx),h_outfile);
	fwrite(WavData2,sizeof(BYTE),0x08,h_outfile);

	while(1)
	{
		while(ret == MP3_OK) {
			fwrite(out,sizeof(BYTE),size,h_outfile);
			itotal_pcm_size += size;
			ret = mp3towav.decode(NULL,0,(BYTE *)out,8192,&size);
		}

		len = fread(buf,sizeof(BYTE),BUF_SIZE,h_infile);
		if(callback){
			if(!((dec_callback)callback)(ftell(h_infile),file_size)){
				//�n���h������
				fclose(h_infile);
				fclose(h_outfile);
				return -100;
			}
		}

		if(len <= 0) break;

		ret = mp3towav.decode((const BYTE *)buf,len,(BYTE *)out,8192,&size);
	}

	//wav��񏑂�����
	if (fseek(h_outfile, 42, SEEK_SET) == 0)
	{
		fwrite(&itotal_pcm_size, 1, sizeof(DWORD), h_outfile);

		if (fseek(h_outfile, 4, SEEK_SET) == 0)
		{
			itotal_pcm_size += 0x26;
			fwrite(&itotal_pcm_size, 1, sizeof(DWORD), h_outfile);
		}
	}

	//�n���h������
	fclose(h_infile);
	fclose(h_outfile);

	return TRUE;
}

//in_mpg123.cpp���
bool head_chk(unsigned int head)
{
	if((head & 0xffe00000) != 0xffe00000) return false;

	const int	lay = (head >> 17) & 3;

	if(lay == 0) return false;

	const int	freq = (head >> 10) & 0x3;

	if(freq == 0x3) return false;

	const int	bitrate = (head >> 12) & 0xf;

	if((bitrate == 0x0) || (bitrate == 0xf)) return false;

	return true;
}