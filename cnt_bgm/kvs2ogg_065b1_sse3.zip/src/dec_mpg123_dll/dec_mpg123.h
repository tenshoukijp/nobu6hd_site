#ifndef __DEC_MPG123_H__
#define __DEC_MPG123_H__

#define DllExport __declspec(dllexport)

DllExport int WINAPI mpg123_dec(char *sInFile, char *sOutFile,FARPROC callback);

typedef int (CALLBACK *dec_callback)(long,long);

#endif	// __DEC_MPG123_H__
 