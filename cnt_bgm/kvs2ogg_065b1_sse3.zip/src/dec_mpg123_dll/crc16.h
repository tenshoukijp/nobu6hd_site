
class
crc16
{
public:
	inline static unsigned int	Calc(unsigned int crc, unsigned char* Buff, const int Size)
	{
		for(int Idx = 0; Idx < Size; Idx++) {
			crc = Calc(crc, *Buff++);
		}

		return crc;
	}

private:
	static const unsigned int	Table_crc[];

	inline static unsigned int	Calc(const unsigned int crc, unsigned char Buff)
	{
		return Table_crc[(crc ^ Buff) & 0xff] ^ (crc >> 8);
	}
};

